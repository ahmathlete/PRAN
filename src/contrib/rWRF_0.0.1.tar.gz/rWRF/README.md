
# rWRF <img src="man/figures/logo.png" align="right" height="138" />

<!-- badges: start -->
[![License: GPL v3.0](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0)
![GitHub last commit](https://img.shields.io/github/last-commit/ahmathlete/rWRF)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
![GitHub R package
version](https://img.shields.io/github/r-package/v/ahmathlete/rWRF)
[![R-CMD-check](https://github.com/ahmathlete/rWRF/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/ahmathlete/rWRF/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

The goal of rWRF is to ...

## Installation

You can install the development version of rWRF from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("ahmathlete/rWRF")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(rWRF)
## basic example code
```

## Poem 
Thanks to ChatGPT for generating this beautiful poem. 

The road to WRF modelling,\
Is long and winding and bumpy,\
But once you master its secrets,\
The world of climate modelling,\
Is yours to explore and discover.

With WRF under your belt,\
You can take on any model,\
ICON, GFS, and more,\
Your skills and knowledge,\
Will open doors,\
To a world of weather and climate,\
A world of endless possibilities.

So keep on learning,\
And never give up,\
For the road may be tough,\
But the rewards,\
Are well worth the effort,\
In the world of climate modelling.
