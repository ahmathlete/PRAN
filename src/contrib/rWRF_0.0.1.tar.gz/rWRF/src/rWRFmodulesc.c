#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <Rmath.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Arith.h>

void F77_NAME(add_f)(double *x, double *y, double *ret);
void F77_NAME(rWRF_get_width_heights_4geomtile_f)(int nlat, int nlon, int ntime, double *X_LON_C, \
                          double *X_LAT_C, int nlat1, int nlon1, \
                          double *height_arr, double *width_arr);
void F77_NAME(rWRF_deaccumulate_precipitation_data_f)(int nlat, int nlon, int ntime, int timestep, \
                          double *RAINC_arr, double *RAINNC_arr, double *final_arr);
void F77_NAME(rWRF_test_openmp_f)(int *result);

extern SEXP c_add_f(SEXP x, SEXP y){
  SEXP ret;
  PROTECT(ret = allocVector(REALSXP, 1));
  F77_CALL(add_f)(REAL(x), REAL(y), REAL(ret));
  UNPROTECT(1);
  return(ret);

}

extern SEXP c_rWRF_get_width_heights_4geomtile_f(SEXP DIM_ARRAY, \
                                                     SEXP X_LON_C, \
                                                     SEXP X_LAT_C){
  int nlat = INTEGER(DIM_ARRAY)[0];
  int nlon = INTEGER(DIM_ARRAY)[1];
  int ntime = INTEGER(DIM_ARRAY)[2];

  int nlat1 = nlat -1;
  int nlon1 = nlon -1;

  SEXP height_arr;
  SEXP width_arr;

  PROTECT(height_arr = alloc3DArray(REALSXP, nlat1 , nlon1, ntime));
  PROTECT(width_arr  = alloc3DArray(REALSXP, nlat1 , nlon1, ntime));
  F77_CALL(rWRF_get_width_heights_4geomtile_f)(nlat, nlon, ntime,  \
           REAL(X_LON_C), REAL(X_LAT_C), nlat1, nlon1,\
            REAL(height_arr), REAL(width_arr));

  SEXP list;

  /* Allocate the list object */
  PROTECT(list = Rf_allocVector(VECSXP, 2));

  /* Set the first element of the list to x */
  SET_VECTOR_ELT(list, 0, height_arr);

  /* Set the second element of the list to y */
  SET_VECTOR_ELT(list, 1, width_arr);

  UNPROTECT(3);
  return list;
}

extern SEXP c_rWRF_deaccumulate_precipitation_data_f(SEXP DIM_ARRAY, \
                                                     SEXP RAINC_arr, \
                                                     SEXP RAINNC_arr){
  int nlat = INTEGER(DIM_ARRAY)[0];
  int nlon = INTEGER(DIM_ARRAY)[1];
  int ntime = INTEGER(DIM_ARRAY)[2];
  int timestep = INTEGER(DIM_ARRAY)[3];

  SEXP final_arr;

  PROTECT(final_arr = alloc3DArray(REALSXP, nlat, nlon, ntime));
  F77_CALL(rWRF_deaccumulate_precipitation_data_f)(nlat, nlon, ntime, timestep, \
           REAL(RAINC_arr), REAL(RAINNC_arr), REAL(final_arr));
  UNPROTECT(1);
  return(final_arr);

}


extern SEXP c_rWRF_test_openmp_f(SEXP input){

  F77_CALL(rWRF_test_openmp_f)(INTEGER(input));
  return(input);

}

static const R_CallMethodDef CallEntries[] = {
 {"c_add_f",           (DL_FUNC) &c_add_f,                   2},
 {"c_rWRF_get_width_heights_4geomtile_f",       \
   (DL_FUNC) &c_rWRF_get_width_heights_4geomtile_f,           3},
 {"c_rWRF_deaccumulate_precipitation_data_f",  \
  (DL_FUNC) &c_rWRF_deaccumulate_precipitation_data_f,       3},
 {"c_rWRF_test_openmp_f",  \
  (DL_FUNC) &c_rWRF_test_openmp_f,       1},
 {NULL,         NULL,               0}
};



static const R_FortranMethodDef FEntries[] = {
  {NULL,         NULL,               0}
};



void R_init_rWRF(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, FEntries, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
