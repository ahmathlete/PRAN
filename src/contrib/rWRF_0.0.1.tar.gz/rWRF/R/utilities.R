era5_ml <- function() {
  readLines(system.file("scripts/era5_ml.py", package = "rWRF"))
}

era5_sfc <- function() {
  readLines(system.file("scripts/era5_sfc.py", package = "rWRF"))
}

era5_slurm <- function() {
  readLines(system.file("scripts/era5_slurm.sh", package = "rWRF"))
}

era5_split <- function() {
  readLines(system.file("scripts/era5_split.sh", package = "rWRF"))
}

namelist_wps_template <- function() {
  readLines(system.file("scripts/namelist.wps", package = "rWRF"))
}
namelist_input_template <- function() {
  readLines(system.file("scripts/namelist.input", package = "rWRF"))
}
# get width and height for WRF grid cells
rWRF_get_width_heights_4geomtile <- function(geogrid_d01_file) {
  # get corners crds to calculate height and width of grid cells
  r.lonC <- terra::rast(geogrid_d01_file, subds = "XLONG_C") %>%
    terra::as.array()
  r.latC <- terra::rast(geogrid_d01_file, subds = "XLAT_C") %>%
    terra::as.array()

  # Fortran
  result <- .Call(
    "c_rWRF_get_width_heights_4geomtile_f",
    DIM_ARRAY = as.integer(dim(r.lonC)), # 3D
    X_LON_C = as.double(r.lonC),
    X_LAT_C = as.double(r.latC)
  )

  result <- lapply(result, FUN = function(xx) {
    xdim <- dim(xx)

    x.df <- xx %>%
      dplyr::as_tibble() %>%
      dplyr::mutate(y = 1:xdim[1]) %>%
      tidyr::pivot_longer(-y) %>%
      dplyr::rename(x = name, r.value = value) %>%
      dplyr::mutate(x = as.numeric(stringr::str_extract(x, "(\\d)+")))
  })

  names(result) <- c("Kheight", "Kwidth")

  result <- result %>%
    purrr::reduce(dplyr::inner_join, by = c("x", "y")) %>%
    dplyr::rename(
      Kheight = r.value.x,
      Kwidth = r.value.y
    )


  return(result)
}




# fields::image.plot(t(apply(r.latC[,,1], 2, rev)))
# fields::image.plot(t(apply(r.lonC[,,1], 2, rev)))
