#' Deaccumulate precipitation from WRF output files
#'
#' This function deaccumulates precipitation from WRF output files given by their
#' location and writes the deaccumulated precipitation to a new file.
#'
#' @param fileSname The name of the WRF output files, for only one domain e.g., wrfout_d01
#' @param RAINC Logical, if Cumulus precipitation should be included or not.
#' @param RAINNC Logical, if all grid cell precipitation should be included or not.
#' @param output.path The directory path where the output file will be written.
#'
#' @return One file for each domain including the deaccumulated precipitation
#' @export
#'
rWRF_deaccumulate_precipitation_data <- function(fileSname,
                                                 RAINC = TRUE,
                                                 RAINNC = TRUE,
                                                 output.path) {
  message("Provided ", length(fileSname), " files. They will be processed into one BIG file")

  meta_df <- data.frame(
    INDEX = rep(NA, length(fileSname)),
    NAME = rep(NA, length(fileSname)),
    XTIME = rep(NA, length(fileSname)),
    XTIME1 = rep(NA, length(fileSname)),
    XTIME2 = rep(NA, length(fileSname)),
    XTIME_attr = rep(NA, length(fileSname)),
    RAINC_arr = rep(NA, length(fileSname)),
    RAINNC_arr = rep(NA, length(fileSname))
  )

  for (ifile in seq_along(1:length(fileSname))) {
    meta_df$INDEX[ifile] <- ifile
    meta_df$NAME[ifile] <- fileSname[ifile]

    # open the file
    nc_file <- ncdf4::nc_open(fileSname[ifile])

    # get time step to calculate mm/hr
    meta_df$XTIME[ifile] <- list(ncdf4::ncvar_get(nc_file, "XTIME"))
    meta_df$XTIME1[ifile] <- ncdf4::ncvar_get(nc_file, "XTIME")[1]
    meta_df$XTIME2[ifile] <- ncdf4::ncvar_get(
      nc_file,
      "XTIME"
    )[length(ncdf4::ncvar_get(
      nc_file,
      "XTIME"
    ))]
    meta_df$XTIME_attr[ifile] <- ncdf4::ncatt_get(nc_file, "XTIME")$description

    # get convective rain
    if (RAINC) {
      meta_df$RAINC_arr[ifile] <- list(ncdf4::ncvar_get(nc_file, "RAINC"))
    }

    # get non convective rain
    if (RAINNC) {
      meta_df$RAINNC_arr[ifile] <- list(ncdf4::ncvar_get(nc_file, "RAINNC"))
    }

    # close the file
    ncdf4::nc_close(nc_file)
  }

  # combine inputs
  meta_df <- meta_df[order(meta_df$XTIME1), ]

  all.time <- abind::abind(meta_df$XTIME)

  # pre-process before fortran
  if (RAINC & RAINNC) {
    r.RAINC <- abind::abind(meta_df$RAINC_arr)
    r.RAINNC <- abind::abind(meta_df$RAINNC_arr)
  } else if (!RAINNC) {
    message("Not considering ACCUMULATED TOTAL GRID SCALE PRECIPITATION")
    r.RAINC <- abind::abind(meta_df$RAINC_arr)
    r.RAINNC <- array(0, dim = dim(r.RAINC))
  } else if (!RAINC) {
    message("Not considering ACCUMULATED TOTAL CUMULUS PRECIPITATION")
    r.RAINNC <- abind::abind(meta_df$RAINNC_arr)
    r.RAINC <- array(0, dim = dim(r.RAINNC))
  } else {
    stop("Please indicate which preciption variables should be deaccumlated!")
  }

  timestep <- all.time[2] - all.time[1]
  message("The data has ", timestep, " mins resoultion")

  # fortran
  result <- .Call(
    "c_rWRF_deaccumulate_precipitation_data_f",
    DIM_ARRAY = as.integer(c(dim(r.RAINC), timestep)),
    RAINC_arr = as.double(r.RAINC),
    RAINNC_arr = as.double(r.RAINNC)
  )

  # test
  # set.seed(50)
  # result <- .Call(
  #   "c_rWRF_deaccumulate_precipitation_data_f",
  #   DIM_ARRAY = as.integer(c(5,5,5,60)),
  #   RAINC_arr = as.double(array(runif(50, 1, 99), dim = c(5,5,5))),
  #   RAINNC_arr = as.double(array(runif(50, 1, 99), dim = c(5,5,5)))
  # )

  # write netcdf

  r.result <- terra::rast(result)

  terra::time(r.result) <- as.POSIXct(all.time,
    tz = "UTC",
    origin = NULL
  )


  terra::writeCDF(
    x = result,
    filename = temp_file,
    overwrite = FALSE,
    zname = "time"
  )


  # clean
}

# save.image(file = "my_work_space.RData")
# load("/home/ahmed/Desktop/my_work_space.RData")
