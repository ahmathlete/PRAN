# name of simulation
# will create ERA5 data
# will create Get scripts and slurm
# will create splitted data subfolder
#
create_SIMDIR <- function(WRFDIR,
                          WPSDIR,
                          SIMPATH,
                          SIMDIR) {
  # create sim dir
  SIMDIR <- paste0(SIMPATH, SIMDIR)
  dir.create(SIMDIR)

  # copy WPS dir
  Destination_WPSDIR <- paste0(
    SIMDIR,
    "/WPSCOPY/"
  )
  dir.create(Destination_WPSDIR)

  system(paste0(
    "cp --preserve=links -rf ",
    WPSDIR, "* ",
    Destination_WPSDIR
  ))

  # fix symlink issue
  setwd(Destination_WPSDIR)
  message(paste("Now the working directory is:", getwd()))
  system("find ./ -type l -execdir bash -c 'ln -sfn \"$(readlink -f \"$0\")\" \"$0\"' {} \\;")
  system("ls -alh")
  setwd(SIMDIR)
  message(paste("Now the working directory is:", getwd()))

  # copy WRF dir
  Destination_WRFDIR <- paste0(
    SIMDIR,
    "/WRFCOPY/"
  )
  dir.create(Destination_WRFDIR)

  system(paste0(
    "cp --preserve=links -rf ",
    WRFDIR, "/* ",
    Destination_WRFDIR
  ))

  # fix symlink issue
  setwd(Destination_WRFDIR)
  message(paste("Now the working directory is:", getwd()))
  system("find ./ -type l -execdir bash -c 'ln -sfn \"$(readlink -f \"$0\")\" \"$0\"' {} \\;")
  system("ls -alh")
  setwd(SIMDIR)
  message(paste("Now the working directory is:", getwd()))


  # create other directors for WPS and WRF
  dir.create(paste0(SIMDIR, "/RawData"))
  dir.create(paste0(SIMDIR, "/PreProcessedData"))
  dir.create(paste0(SIMDIR, "/GEOGRID"))
  dir.create(paste0(SIMDIR, "/UNGRIB"))
  dir.create(paste0(SIMDIR, "/METGRID"))
  dir.create(paste0(SIMDIR, "/WRFOUT"))
}

WRFDIR <- "/home/ahho623a/WRF/WRF-4.3.1/run_portable/"
WPSDIR <- "/home/h7/ahho623a/WRF/WPS-4.3.1/"
SIMPATH <- "/beegfs/.global1/ws/ahho623a-WRF_AP/"
SIMDIR <- "SDN1988V4"
