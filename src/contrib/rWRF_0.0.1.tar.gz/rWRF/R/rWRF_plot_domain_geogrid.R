#' @title Plot WRF Domains
#' @description
#' Plotting WRF domains by passing the location of geogrid.exe output.
#' @param geogrid.path A string variable pointing the path of geo_em.dx.nc files.
#' @param overlay The variable to be plotted such as topography. i.e., HGT_M.
#' Only fixed overlay are  considered so far.
#' @author Ahmed Homoudi
#' @importFrom utils data
#' @return  PNG
#' @export

rWRF_plot_domain_geogrid <- function(geogrid.path,
                                     overlay) {
  # input data

  # files
  nc_files <- list.files(
    path = geogrid.path,
    pattern = "geo_*",
    full.names = TRUE
  )

  message("Found ", length(nc_files), " Files, is it correct? Otherwise, please check!")

  # extract domains as polygons
  for (igeo in 1:length(nc_files)) {
    r.lat <- terra::rast(nc_files[igeo], subds = "XLAT_C") %>%
      terra::as.array()
    r.lon <- terra::rast(nc_files[igeo], subds = "XLONG_C") %>%
      terra::as.array()

    # randomly to ensure comparability
    r.rows <- dim(r.lat)[1]
    r.cols <- dim(r.lon)[2]

    if (igeo == 1) {
      Result <- data.frame(
        r.y = c(
          r.lat[1:r.rows, 1, 1],
          r.lat[r.rows, 2:r.cols, 1],
          r.lat[c(r.rows - 1):1, r.cols, 1],
          r.lat[1, c(r.cols - 1):1, 1]
        ),
        r.x = c(
          r.lon[1:r.rows, 1, 1],
          r.lon[r.rows, 2:r.cols, 1],
          r.lon[c(r.rows - 1):1, r.cols, 1],
          r.lon[1, c(r.cols - 1):1, 1]
        )
      ) %>%
        sf::st_as_sf(coords = c("r.x", "r.y"), crs = 4326) %>%
        sf::st_bbox() %>%
        sf::st_as_sfc() %>%
        sf::st_as_sf()

      Result$kname <- stringr::str_to_upper(stringr::str_extract(
        string = nc_files[igeo],
        pattern = "(?<=geo_em.).*(?=.nc)"
      ))
    } else {
      result <- data.frame(
        r.y = c(
          r.lat[1:r.rows, 1, 1],
          r.lat[r.rows, 2:r.cols, 1],
          r.lat[c(r.rows - 1):1, r.cols, 1],
          r.lat[1, c(r.cols - 1):1, 1]
        ),
        r.x = c(
          r.lon[1:r.rows, 1, 1],
          r.lon[r.rows, 2:r.cols, 1],
          r.lon[c(r.rows - 1):1, r.cols, 1],
          r.lon[1, c(r.cols - 1):1, 1]
        )
      ) %>%
        sf::st_as_sf(coords = c("r.x", "r.y"), crs = 4326) %>%
        sf::st_bbox() %>%
        sf::st_as_sfc() %>%
        sf::st_as_sf()

      result$kname <- stringr::str_to_upper(stringr::str_extract(
        string = nc_files[igeo],
        pattern = "(?<=geo_em.).*(?=.nc)"
      ))

      Result <- rbind(Result, result)
    }
  }

  rm(result):gc()

  # get overlay layer
  r.overlay <- terra::rast(nc_files[which(Result$kname == "D01")], subds = overlay) %>%
    terra::as.data.frame(xy = TRUE)
  r.lon <- terra::rast(nc_files[which(Result$kname == "D01")], subds = "XLONG_M") %>%
    terra::as.data.frame(xy = TRUE)
  r.lat <- terra::rast(nc_files[which(Result$kname == "D01")], subds = "XLAT_M") %>%
    terra::as.data.frame(xy = TRUE)

  r.overlay <- r.overlay %>%
    dplyr::right_join(r.lon, by = c("x", "y")) %>%
    dplyr::right_join(r.lat, by = c("x", "y")) %>%
    dplyr::left_join(rWRF_get_width_heights_4geomtile(nc_files[which(Result$kname == "D01")]),
      by = c("x", "y")
    )

  names(r.overlay) <- c(
    "Kx",
    "Ky",
    "Kvar",
    "Klon",
    "Klat",
    "Kheight",
    "Kwidth"
  )

  # fix tiles issue and unify projection
  ncin <- ncdf4::nc_open(nc_files[1])
  global_atts <- ncdf4::ncatt_get(ncin, 0)

  if (global_atts$MAP_PROJ == 1) {

  } else if (global_atts$MAP_PROJ == 2) {
    # Define the Polar Stereographic projection string
    my_proj <- paste0(
      "+proj=stere +lat_0=", global_atts$CEN_LAT,
      " +lat_ts=", global_atts$CEN_LAT,
      " +lon_0=", global_atts$CEN_LON,
      " +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs"
    )
  } else if (global_atts$MAP_PROJ == 3) {
    # Define the Mercator projection string
    my_proj <- paste0(
      "+proj=merc +lat_0=", global_atts$CEN_LAT,
      " +lon_0=", global_atts$CEN_LON,
      " +k_0=", global_atts$FLAG_MF_XY
    )
  } else if (global_atts$MAP_PROJ == 6) {
    message("latitude and longitude (including global), Still working on that!, Sorry :(")
  }


  ncdf4::nc_close(ncin)

  # prepare polygons
  names(Result) <- c("Kname", "geometry")
  sf::st_geometry(Result) <- "geometry"
  # Result<- sf::st_transform(Result, crs = my_proj)


  # for plotting create coordinates to add domains title
  # should be the top center point.
  labels_locations <- data.frame(t(apply(Result, 1, function(x) {
    sf::st_bbox(x$geometry)
  })))

  labels_locations$Kname <- Result$Kname

  # plotting

  # future plan
  # check other variables in geogrid that needs to be plotted
  # use if statement for that

  if (overlay == "HGT_M") {
    legendtitle <- "Elevation [m]"
  }
  # limits
  limits <- sf::st_bbox(sf::st_buffer(sf::st_as_sfc(sf::st_bbox(Result)),
    dist = 0.5
  ))

  (ggplot2::ggplot() +
    ggplot2::geom_tile(
      data = r.overlay,
      mapping = ggplot2::aes(
        x = Klon,
        y = Klat,
        fill = Kvar,
        width = Kwidth,
        height = Kheight
      )
    ) +
    ggplot2::scale_fill_gradientn(legendtitle,
      colours = cptcity::cpt(pal = "wkp_schwarzwald_wiki_schwarzwald_cont"),
    ) +
    ggplot2::geom_sf(rWRF::Administrative_boundaries,
      mapping = ggplot2::aes(),
      fill = NA,
      linewidth = 0.2,
      color = "grey31"
    ) +
    ggplot2::geom_sf(rWRF::Rivers,
      mapping = ggplot2::aes(),
      fill = NA,
      linewidth = 0.2,
      color = "blue"
    ) +
    ggplot2::geom_sf(
      data = Result,
      fill = NA,
      linewidth = 0.5,
      color = "black"
    ) +
    ggplot2::geom_text(
      data = labels_locations,
      mapping = ggplot2::aes(
        x = xmin,
        y = ymax,
        label = Kname
      ),
      lineheight = 3.5,
      colour = "magenta",
      check_overlap = TRUE,
      vjust = 0, nudge_y = 0.07
    ) +
    ggplot2::coord_sf(
      xlim = limits[c(1, 3)],
      ylim = limits[c(2, 4)],
      crs = my_proj,
      default_crs = sf::st_crs(rWRF::Rivers)
    ) +
    ggplot2::theme_bw(base_size = 8) +
    ggplot2::xlab("") +
    ggplot2::ylab("") +
    ggplot2::theme(
      legend.key.width = ggplot2::unit(3, "mm"),
      legend.key.height = ggplot2::unit(7.5, "mm"),
      legend.title = ggplot2::element_text(size = 5),
      legend.text = ggplot2::element_text(size = 4)
    )) %>%
    ggplot2::ggsave(
      filename = paste0(
        geogrid.path,
        "/plot_WRF_domains_",
        overlay,
        ".png"
      ),
      units = "mm",
      height = 100,
      width = 110,
      dpi = 600
    )
}


# geogrid.path<-"/media/SSD2/Small_projects/SDN_WRF_1988/WRF/GEOGRID/"
# overlay<-"HGT_M"
# geogrid_d01_file<-nc_files[which(Result$kname == "D01")]
