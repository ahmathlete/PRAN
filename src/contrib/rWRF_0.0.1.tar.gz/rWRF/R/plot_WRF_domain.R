#' @title Plot WRF Domain from namelist.wps file
#' @description A function
#'
#' @param namelist.wps the path to the namelist.wps file.
#' @param output.path the path to where the plot should be saved.
#' @author Ahmed Homoudi
#' @export
#'
plot_WRF_domain <- function(namelist.wps,
                            output.path) {
  cat(namelist.wps)
  cat(output.path)
}
# do i=1,n_domains
# ixdim(i) = e_we(i) - s_we(i) + 1
# jydim(i) = e_sn(i) - s_sn(i) + 1
# end do
