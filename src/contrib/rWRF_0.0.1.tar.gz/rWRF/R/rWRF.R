#' rWRF: A package for Identification and Description of Precipitation Systems.
#'
#' The rWRF package provides three categories of important functions:
#' foo, bar and baz.
#'
#' @section rWRF functions:
#' The rWRF functions ...
#'
#' @docType package
#' @name rWRF
#' @useDynLib rWRF, .registration=TRUE
NULL
#> NULL
