#' @title Rivers
#' @description  Data of shapefile of World big rivers
#'
#'
#' @format A tibble with 977 rows and 2 variables:
#' \describe{
#'   \item{RIVER}{Name of the river}
#'   \item{geom}{geometry of the river}
#' }
#' @source Bundesanstalt für Gewässerkunde - 2023
#'  \url{https://www.bafg.de/SharedDocs/ExterneLinks/GRDC/mrb_shp_zip.html?nn=201762}
"Rivers"
