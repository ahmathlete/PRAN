#' @name Administrative_boundaries
#' @title Administrative_boundaries
#' @description  Data of shapefile of World Administrative_boundaries
#'
#'
#' @format A tibble with 256 rows and 9 variables:
#' @source opendatasoft - 2023
#'  \url{https://public.opendatasoft.com/explore/dataset/world-administrative-boundaries/export/}
#' @keywords dataset
"Administrative_boundaries"
