#!bin/bash 
#Submit this script with: sbatch thefilename

#SBATCH --time=6:00:00  # walltime
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4  # number of processor cores (i.e. threads)
#SBATCH --partition=haswell
#SBATCH --mem-per-cpu=2000   # memory per CPU core
#SBATCH -J "Split_ERA5_for_WRF_AP1988"   # job name
#SBATCH --mail-user=ahmed.homoudi@tu-dresden.de  # email address
#SBATCH --mail-type=BEGIN,END,FAIL,REQUEUE
#SBATCH -A p_precipitation_systems
#SBATCH --output=outp-m-%j.out
#SBATCH --error=erro-m-%j.out
#salloc --account=p_precipitation_systems --nodes=1 --cpus-per-task=24 --time=06:00:00

module restore default 

export Working_dir=/beegfs/.global1/ws/ahho623a-ERA5_WRF_AP/AP1988/ERA5
cd ${Working_dir}

cdo -V 

# ML files 
# declare an array variable
declare -a ML_files=($(ls ERA5_ML_*.grib))

echo ${ML_files}

# test 
for j in "${ML_files[@]}" 
do 
echo 'file j is' && echo $j
v2=${j::-10}
echo $v2
done 

for j in "${ML_files[@]}" 
do 
v2=${j::-10} && echo $v2
cdo splithour $j ../Data/$v2
done 


# SFC files 
# declare an array variable
declare -a SFC_files=($(ls ERA5_SFC_*.grib))

echo ${SFC_files}

# test 
for j in "${SFC_files[@]}" 
do 
echo 'file j is' && echo $j
v2=${j::-10}
echo $v2
done 

for j in "${SFC_files[@]}" 
do 
v2=${j::-10} && echo $v2
cdo splithour $j ../Data/$v2
done 
