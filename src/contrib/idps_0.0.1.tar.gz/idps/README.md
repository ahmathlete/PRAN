
# idps <img src="man/figures/logo.png" align="right" height="138" />

<!-- badges: start -->
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![R-CMD-check](https://github.com/ahmathlete/idps/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/ahmathlete/idps/actions/workflows/R-CMD-check.yaml)
[![License: GPL
v3.0](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0)
![GitHub R package
version](https://img.shields.io/github/r-package/v/ahmathlete/idps)
![GitHub last commit](https://img.shields.io/github/last-commit/ahmathlete/idps)
<!-- badges: end -->

The goal of idps is to use object-based methods combined with a tracking 
algorithm to utilise the GPM_3IMERGHH (V06) data set to identify and describe 
precipitation systems. idps stands for **I**dentification and **D**escription of **P**recipitation **S**ystems.

## Installation

You can install the development version of idps from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("ahmathlete/idps")
```

``` r
install.packages("pak")
pak::pkg_install("ahmathlete/idps")
``` 

The `R CMD CHECK` workflow doesn't succeed on GitHub. The Package will be checked 
continuously on a Windows machine. The steps to compile it on Windows: 


## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(idps)
## basic example code
```
Some functions within the packages are not exported. You might need to use `idps:::function`.
Generally, `:::` is used to access the internal members of the package. See `help(":::")`.

## Poem 
Thanks to [ChatGPT](https://chat.openai.com/chat) for generating this beautiful poem. 

Clouds swirl and spin,\
In tropical cyclones and fronts,\
Precipitation falls within,\
Nature's beauty in abundance.

Convective clouds arise,\
From heated land below,\
A cool and welcome surprise,\
In the sky's endless show.

Clouds bring rain and snow,\
Nourishing the earth below,\
A cool and beautiful glow,\
In the sky's endless flow.
