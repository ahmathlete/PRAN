## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval=FALSE--------------------------------------------------------------
#  library(idps)
#  # Define the date
#  DATE <- "2011-09-30"
#  
#  path <- "/path/to/where/files/should/be/stored"
#  user <- "username"
#  password <- "your password"
#  # other options are: laterun or earlyrun
#  product <- "finalrun"
#  # other options are available, check the gpm_download function doc.
#  band <- "precipitationCal"
#  lonMin <- 20
#  lonMax <- 70
#  latMin <- -5
#  latMax <- 40
#  # The data is originally in HDF5 format. this will remove original files
#  removeHDF5 <- TRUE
#  quiet <- TRUE
#  
#  gpm_download(
#    path = path,
#    user = user,
#    password = password,
#    dates = DATE,
#    product,
#    band = "precipitationCal",
#    lonMin = lonMin,
#    lonMax = lonMax,
#    latMin = latMin,
#    latMax = latMax,
#    removeHDF5 = TRUE,
#    quiet = TRUE
#  )

## ---- eval=FALSE, include=TRUE------------------------------------------------
#  library(idps)
#  
#  path <- "/path/to/where/files/should/be/stored"
#  output.path <- "/path/to/where/aggregated-files/should/be/stored"
#  
#  netCDF.files <- list.files(
#    path = path,
#    full.names = T,
#    pattern = ".nc$"
#  )
#  
#  aggregate_netCDF_files(
#    netCDF.files,
#    output.path
#  )

