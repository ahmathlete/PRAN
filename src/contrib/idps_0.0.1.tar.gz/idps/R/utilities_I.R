# This function gets the mean time from HDF5 file name
get_time_from_HDF5_filename <- function(hdf5.name) {
  hdf5.names <- unlist(stringr::str_split(hdf5.name, "[.]"))

  time_part <- unlist(stringr::str_split(grep(pattern = "-S", hdf5.names, value = T), "-"))

  time_bounds <- c(
    lubridate::ymd_hms(paste0(
      time_part[1],
      gsub("[^0-9.-]", "", time_part[2])
    )),
    lubridate::ymd_hms(paste0(
      time_part[1],
      gsub("[^0-9.-]", "", time_part[3])
    ))
  )

  return(mean(time_bounds))
}


# use wget to download GPM files as HDF5
wget.R <- function(url, user, password, dest_path, quiet) {
  if (Sys.info()[1] == "Windows") {
    wget_command <- "wget --load-cookies C:\\.urs_cookies C:\\.urs_cookies "
  } else {
    wget_command <- "wget --load-cookies "
  }

  if (quiet) {
    wget_command <- paste(wget_command, "--no-verbose")
  }

  # add destiantion path
  wget_command <- paste0(wget_command, " --directory-prefix=", dest_path)

  # add credentials
  wget_command <- paste(
    wget_command,
    "--user",
    user,
    "--password",
    password,
    url
  )

  system(wget_command)
}


# check the continuity of the daily downloaded files.

check_missing_days <- function(path2netcdf_files = "~/",
                               expected_start = "2000-06-01",
                               expected_end = "2021-09-30",
                               remove_incomplete = TRUE) {
  # list files
  nc.files <- list.files(path2netcdf_files,
    pattern = ".nc$",
    full.names = TRUE
  )

  Dates <- seq.Date(as.Date(expected_start), as.Date(expected_end), by = "day")


  message(paste("Number of expected files/dates", length(Dates)))
  message(paste("Number of found files/dates", length(nc.files)))

  meta.data <- lapply(nc.files, function(x) {
    y <- unlist(stringr::str_split(x, pattern = "_"))

    # 15 because yyyymmdd-hhmmss
    x.times <- y[!is.na(readr::parse_number(y)) & nchar(y) == 15]

    x.times <- y[grep(pattern = "-", y) & nchar(y) == 15]

    return(c(x, x.times))
  })

  meta.data <- as.data.frame(do.call(rbind, meta.data))

  meta.data$DATE1 <- as.Date(lubridate::ymd_hms(meta.data$V2))
  meta.data$DATE2 <- as.Date(lubridate::ymd_hms(meta.data$V3))


  if (length(Dates) != length(nc.files)) {
    message(paste0(
      "There is ",
      length(Dates) - length(nc.files),
      "missing files"
    ))

    # missing files
    message(" Missing Dates are: ")
    print(unique(Dates[!Dates %in% meta.data$DATE1]))
  } else {
    message("No missing files. Now checking missing timesteps withing the daily files.")
  }


  # check that all hours should be 00:00:00

  wrong_starts <- meta.data$V2[!endsWith(meta.data$V2, "000000")]
  wrong_ends <- meta.data$V3[!endsWith(meta.data$V3, "000000")]

  message("These files needs to be redownloaded:")
  print(c(
    meta.data$V1[!endsWith(meta.data$V2, "000000")],
    meta.data$V1[!endsWith(meta.data$V3, "000000")]
  ))

  if (remove_incomplete) {
    message("Removing incomplete files")
    file.remove(c(
      meta.data$V1[!endsWith(meta.data$V2, "000000")],
      meta.data$V1[!endsWith(meta.data$V3, "000000")]
    ))
  }
}

# remove values below a certain thresholds
# replace

f1_remove_below_thresholds <- function(x, threshold) {
  x[x < threshold] <- NA

  return(x)
}

f1_ccl_SpatRaster <- function(x) {
  x_binary <- terra::as.int(!is.na(x))

  x_ccl <- ccl(a = terra::as.array(x_binary))

  x_ccl <- terra::rast(x_ccl,
    crs = terra::crs(x_binary),
    extent = terra::ext(x_binary)
  )

  terra::time(x_ccl) <- terra::time(x_binary)

  return(x_ccl)
}

f1_ccl_area_and_number_object <- function(x_ccl) {
  # x_ccl<-r.ccl[[1]]
  # count objects

  no_layers <- terra::nlyr(x_ccl)

  result <- data.frame(
    TIME = as.character(terra::time(x_ccl)),
    NO_Object = NA,
    Area_Covered = NA
  )

  for (i in 1:no_layers) {
    result$NO_Object[i] <- length(unique(terra::values(x_ccl[[i]],
      na.rm = T
    )))

    result$Area_Covered[i] <- unlist(terra::global(
      terra::cellSize(x_ccl[[i]],
        mask = T
      ),
      "sum",
      na.rm = T
    ))
  }


  return(result)
}

f1_SpatRaster2df_withtime <- function(x) {
  y <- terra::as.data.frame(x, na.rm = TRUE)
  names(y) <- as.character(terra::time(x))
  y$ID <- 1

  y <- tidyr::pivot_longer(y,
    cols = -c("ID"),
    names_to = "TIME",
    values_to = "pr"
  ) %>%
    dplyr::select(-ID)

  return(y)
}

yseason <- function(date) {
  date <- lubridate::month(date)
  return(unlist(lapply(date, function(x) {
    if (x %in% c(12, 1, 2)) {
      season <- "DJF"
    } else if (x %in% c(3, 4, 5)) {
      season <- "MAM"
    } else if (x %in% c(6, 7, 8)) {
      season <- "JJA"
    } else if (x %in% c(9, 10, 11)) {
      season <- "SON"
    } else {
      season <- NA
    }
  })))
}


f1_convert_rast_to_df <- function(x) {
  # x<-r.temp

  x.time <- as.character(terra::time(x))

  x.df <- terra::as.data.frame(x, xy = TRUE, na.rm = FALSE)
  names(x.df) <- c("x", "y", x.time)

  x.df <- x.df %>%
    tidyr::pivot_longer(
      cols = -c("x", "y"),
      names_to = "TIME",
      values_to = "value"
    ) %>%
    dplyr::filter(!is.na(value))

  return(x.df)
}

# https://stackoverflow.com/a/25635740/13818750
Mode <- function(x, na.rm = FALSE) {
  if (na.rm) {
    x <- x[!is.na(x)]
  }

  ux <- unique(x)
  return(ux[which.max(tabulate(match(x, ux)))])
}

cbindx <- function(x, y) {
  n <- max(length(x), length(y))
  length(x) <- n
  length(y) <- n
  return(cbind(x, y))
}


df2WKT <- function(x) {
  x.result <- unlist(lapply(1:nrow(x), FUN = function(z) {
    paste0("(", paste0(sprintf("%.3f", x[z, ]), collapse = " "), ")")
  }))

  # add comma after each grid point
  x.result[1:c(length(x.result) - 1)] <- paste0(x.result[1:c(length(x.result) - 1)], ",")


  x.result <- paste0(
    "MULTIPOINT M(",
    paste0(x.result, collapse = " "),
    ")"
  )

  return(x.result)
}

CF_standards <- function() {
  utils::read.csv(system.file("standards/standards_uv_st.csv",
    package = "idps"
  ))
}

convertPOSIXct2numeric <- function(time_vector,
                                   timeunits = "hours since 1971-01-01 00:00:00") {
  x.tmp <- strsplit(timeunits, " ")[[1]]

  reference <- as.POSIXct(paste(x.tmp[3:4], collapse = " "),
    tz = "UTC"
  )

  time_numeric <- as.numeric(difftime(time_vector,
    reference,
    units =
      x.tmp[1]
  ))

  return(time_numeric)
}
