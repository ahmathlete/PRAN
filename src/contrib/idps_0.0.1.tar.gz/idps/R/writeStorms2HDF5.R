writeStorms2HDF5 <- function(x,
                             filename,
                             outputpath = "~/",
                             verbose = FALSE) {
  # create filename
  filename <- paste0(outputpath, filename)

  # to avoid error, remove file if it exists
  if (file.exists(filename)) file.remove(filename)

  # check storms
  no.storms <- length(x)
  message("Found ", no.storms, " Storms")

  if (verbose) {
    for (igroup in 1:no.storms) {
      message(
        "Storm No.",
        igroup,
        " has ",
        dim(x[[igroup]])[1],
        " timesteps."
      )
    }
  }

  # create HDF5 file
  rhdf5::h5createFile(filename)

  Storms.names <- names(x)

  for (igroup in 1:no.storms) {
    rhdf5::h5createGroup(file = filename, group = Storms.names[igroup])
  }

  for (igroup in 1:length(x)) {
    rhdf5::h5write(
      obj = x[[igroup]]$timesep,
      file = filename,
      name = paste0(Storms.names[igroup], "/timesep")
    )

    rhdf5::h5write(
      obj = x[[igroup]]$PC,
      file = filename,
      name = paste0(Storms.names[igroup], "/PC")
    )
  }


  rhdf5::h5closeAll()
}
