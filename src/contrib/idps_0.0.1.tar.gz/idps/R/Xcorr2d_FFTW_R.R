#' @title Calculate the 2D cross-correlation of two matrices using R-ffwtools-package
#'
#' @description  This function calculates the 2D cross-correlation of two matrices
#'  `a` and `b` using R-ffwtools-package.
#'
#' @param a A matrix (2D array) of values.
#' @param b A matrix (2D array) of values.
#' @return A matrix representing the 2D cross-correlation of the input matrices.
#' @export
#' @examples
#' a <- matrix(c(1, 2, 3, 4), ncol = 2)
#' b <- matrix(c(5, 6, 7, 8), ncol = 2)
#' cc <- Xcorr2d_FFT_R(a, b)
#' image(cc)
#' @author Ahmed Homoudi
#' @seealso \link{PIV_obtain_grid}
#' @useDynLib idps
#' @export
Xcorr2d_FFTW_R <- function(a, b) {
  # a<-a-mean(a); b<-b-mean(b)
  # the full CC matrix
  cc_row <- nrow(a) + nrow(b) - 1
  cc_col <- ncol(a) + ncol(b) - 1

  # a
  padded_a <- matrix(0, nrow = cc_row, ncol = cc_col)
  padded_a[1:nrow(a), 1:ncol(a)] <- a

  # b
  padded_b <- matrix(0, nrow = cc_row, ncol = cc_col)
  # padded_b[1:nrow(b), 1:ncol(b)]<-b#[nrow(b):1, ncol(b):1]
  padded_b[nrow(b):cc_row, ncol(b):cc_col] <- b[nrow(b):1, ncol(b):1]

  # fft
  ffta <- matrix(fftwtools::fftw2d(padded_a), nrow(padded_a))
  fftb <- matrix(fftwtools::fftw2d(padded_b), nrow(padded_b))

  # cc
  cc <- matrix(
    Re(fftwtools::fftw2d(Conj(ffta) * fftb, inverse = 1)),
    nrow(padded_a)
  ) / length(padded_a)


  return(cc)
}

# print(c(irow,icol))
# s<-(min_row_shift:max_row_shift)[irow]
# t<-(min_col_shift:max_col_shift)[icol]
# cc_indices[icc]<-icc
# test<-matrix(fftwtools::fftw(a), nrow(a)) * Conj(matrix(fftwtools::fftw(b), nrow(b)))
# test_cc<-matrix(Re(fftwtools::fftw(test, inverse = 1)),
#                     nrow(a))
