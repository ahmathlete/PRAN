#' writeNetCDF
#'
#' The writeNetCDF function is used to write data to a NetCDF file.
#'
#' @param arrays A list of arrays containing the data to be written to the NetCDF file.
#' @param vars A character vector specifying the variable names corresponding to
#' each array in \code{arrays}. Default value is "vu". Other option is "st".
#' @param xcrds A numeric vector representing the x-coordinates for the data (e.g. lat)
#' @param ycrds A numeric vector representing the y-coordinates for the data. (e.g. lon)
#' @param zcrds A numeric vector representing the z-coordinates for the data.
#' @param fcompression An integer value indicating the compression level to be
#' applied when writing the NetCDF file. Valid values range from 0 (no compression)
#' to 9 (maximum compression).
#' @param overwrite A logical value indicating whether to overwrite an existing
#' NetCDF file with the same name. Default value is \code{FALSE}.
#' @param missval See \code{\link{ncvar_def}}
#' @param netCDF_name A character string specifying the name of the NetCDF file
#' to be created.
#' @return None
#'
#' @examples
#' \dontrun{
#' # Example usage of writeCDF function
#' data <- array(rnorm(100), dim = c(10, 10))
#' xcoords <- 1:10
#' ycoords <- 1:10
#' zcoords <- 1
#'
#' writeCDF(list(data),
#'   vars = "temperature", xcrds = xcoords, ycrds = ycoords, zcrds = zcoords,
#'   compression = 6, overwrite = TRUE, missval  = -999, netCDF_name = "example.nc"
#' )
#' }
#'
#' @details
#' The writeCDF function writes the data from the input arrays to a NetCDF file
#' specified by \code{netCDF_name}. The dimensions of the data are determined
#' by the lengths of the coordinate vectors \code{xcrds}, \code{ycrds}, and
#' \code{zcrds}. Each array in \code{arrays} corresponds to a variable named
#' according to the \code{vars} vector.
#'
#' The \code{fcompression} parameter controls the level of compression applied to
#'  the NetCDF file using the zlib compression library. Valid values range from
#'  0 to 9, where 0 indicates no compression and 9 indicates maximum compression.
#'  Higher compression levels result in smaller file sizes but require more
#'  computational resources.
#'
#' By default, the function does not overwrite an existing NetCDF file with the
#' same name. To overwrite an existing file, set the \code{overwrite} parameter
#' to \code{TRUE}.
#'
#'
#' @references
#' For more information on NetCDF files, refer to the NetCDF documentation.
#'
#' @export

writeNetCDF <- function(arrays,
                        vars = "vu",
                        xcrds,
                        ycrds,
                        zcrds,
                        fcompression = 9,
                        overwrite,
                        missval = NA,
                        netCDF_name) {
  # load standard
  metadata_CF <- CF_standards()

  # variables
  variable2write <- strsplit(vars, "")[[1]]

  var1_index <- which(colnames(metadata_CF) == variable2write[1])
  var2_index <- which(colnames(metadata_CF) == variable2write[2])

  # define axis
  dimLON <- ncdf4::ncdim_def(
    name = metadata_CF$lon[1],
    longname = metadata_CF$lon[2],
    units = metadata_CF$lon[4],
    vals = xcrds
  )

  dimLAT <- ncdf4::ncdim_def(
    name = metadata_CF$lat[1],
    longname = metadata_CF$lat[2],
    units = metadata_CF$lat[4],
    vals = ycrds
  )

  dimTime <- ncdf4::ncdim_def(
    name = metadata_CF$time[1],
    longname = metadata_CF$time[2],
    units = metadata_CF$time[4],
    calendar = metadata_CF$time[5],
    vals = convertPOSIXct2numeric(zcrds,
      timeunits = metadata_CF$time[4]
    ),
    unlim = TRUE
  )

  # define variables

  var_def1 <- ncdf4::ncvar_def(
    name = metadata_CF[1, var1_index],
    units = metadata_CF[4, var1_index],
    dim = list(dimLON, dimLAT, dimTime),
    missval = missval,
    longname = metadata_CF[2, var1_index],
    prec = "double",
    compression = fcompression,
    verbose = FALSE
  )

  var_def2 <- ncdf4::ncvar_def(
    name = metadata_CF[1, var2_index],
    units = metadata_CF[4, var2_index],
    dim = list(dimLON, dimLAT, dimTime),
    missval = missval,
    longname = metadata_CF[2, var2_index],
    prec = "double",
    compression = fcompression,
    verbose = FALSE
  )

  # create netCDF file and put arrays
  ncoutput <- ncdf4::nc_create(
    filename = netCDF_name,
    vars = list(var_def1, var_def2),
    force_v4 = TRUE,
    verbose = FALSE
  )

  # put variable
  ncdf4::ncvar_put(ncoutput, var_def1, arrays[[1]][])
  ncdf4::ncvar_put(ncoutput, var_def2, arrays[[2]][])

  # put additional attributes into dimension and data variables
  ncdf4::ncatt_put(ncoutput, "lon", "axis", "X")
  ncdf4::ncatt_put(ncoutput, "lat", "axis", "Y")
  ncdf4::ncatt_put(ncoutput, "time", "axis", "T")
  ncdf4::nc_close(ncoutput)

  # add global attributes
  # ncatt_put(ncoutput,0,"title",title$value)
  # ncatt_put(ncoutput,0,"institution",institution$value)
  # ncatt_put(ncoutput,0,"source",datasource$value)
  # ncatt_put(ncoutput,0,"references",references$value)
  # history <- paste("P.J. Bartlein", date(), sep=", ")
  # ncatt_put(ncoutput,0,"history",history)
  # ncatt_put(ncoutput,0,"Conventions",Conventions$value)
}
