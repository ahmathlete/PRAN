#' @title Obtain the xy coordinates for the PIV displacement vectors
#' @description A function to receive the coordinates in x and y with the size of window
#' for cross correlation in PIV method and produce the coordinates of the displacement vectors or
#' velocities.
#'
#' @param x_coordinates A vector of coordinates in x or lon direction
#' @param y_coordinates A vector of coordinates in y or lat direction
#' @param window_size The size of the sub window or interrogation window size.
#' Default is 16
#'
#' @return data.frame
#' @author Ahmed Homoudi
#' @export

PIV_obtain_grid <- function(
    x_coordinates,
    y_coordinates,
    window_size = 16) {
  ncol1 <- length(x_coordinates)
  nrow1 <- length(y_coordinates)


  x.ID <- seq(window_size / 2, ncol1 - window_size / 2, window_size / 2)
  y.ID <- seq(window_size / 2, nrow1 - window_size / 2, window_size / 2)

  final <- as.data.frame(cbindx(x.ID, y.ID))
  names(final) <- c("x.ID", "y.ID")

  final <- final %>%
    tidyr::expand(x.ID, y.ID) %>%
    dplyr::mutate(
      x.start = x.ID - window_size / 2 + 1,
      x.end = x.start + window_size - 1,
      y.start = y.ID - window_size / 2 + 1,
      y.end = y.start + window_size - 1
    )

  y.res <- mean(abs(diff(y_coordinates)), na.rm = TRUE)
  x.res <- mean(abs(diff(x_coordinates)), na.rm = TRUE)
  message(paste(
    "The grid spacing in x direction is ", x.res,
    "& the grid spacing in y direction is ", y.res
  ))

  final <- final %>%
    dplyr::mutate(
      x.centre = 0.5 * (x_coordinates[x.start] +
        x_coordinates[x.end] +
        x.res),
      y.centre = 0.5 * (y_coordinates[y.start] +
        y_coordinates[y.end] +
        y.res)
    ) %>%
    na.omit()

  # filter

  message(paste0(
    "The last considered x grid point is ", round(x_coordinates[max(final$x.end)],
      digits = 2
    ),
    " & the last considered y grid point is ", round(y_coordinates[max(final$y.end)],
      digits = 2
    )
  ))

  message(
    "this means: \n ", ncol1 - max(final$x.end), " grid points in x direction will be ignored & ",
    nrow1 - max(final$y.end), " grid points in y direction will be ignored in PIV Calculation"
  )

  return(final)
}
