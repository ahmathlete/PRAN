# A global histogram
# A local filter
# An interpolate
# multiple pass to smaller windows
