#' Shifts a 2D array along a specified margin using circular shift.
#'
#' @param x A 2D array or matrix.
#' @param MARGIN An integer indicating the margin along which the shift should be applied:
#'   \itemize{
#'     \item \code{1}: Shift along rows.
#'     \item \code{2}: Shift along columns.
#'     \item \code{3}: Shift along both rows and columns.
#'   }
#'
#' @return The shifted 2D array.
#' @seealso \code{\link{ifftshift}}
#'
#'
#' @export
fftshift <- function(x, MARGIN = 3) {
  DIMx <- dim(x)

  y <- array(
    .Call("c_fftshift_2d_f",
      dimx = as.integer(DIMx),
      twoDarray = as.double(x),
      Margin = as.integer(MARGIN)
    ),
    dim = DIMx
  )
  return(y)
}
#' Reverses the shift performed by fftshift on a 2D array.
#'
#' @param x A 2D array or matrix.
#' @param MARGIN An integer indicating the margin along which the shift should be applied:
#'   \itemize{
#'     \item \code{1}: Shift along rows.
#'     \item \code{2}: Shift along columns.
#'     \item \code{3}: Shift along both rows and columns.
#'   }
#'
#' @return The reverse-shifted 2D array.
#' @seealso \code{\link{fftshift}}
#'
#'
#' @export
ifftshift <- function(x, MARGIN = 3) {
  DIMx <- dim(x)

  y <- array(
    .Call("c_ifftshift_2d_f",
      dimx = as.integer(DIMx),
      twoDarray = as.double(x),
      Margin = as.integer(MARGIN)
    ),
    dim = DIMx
  )
  return(y)
}
