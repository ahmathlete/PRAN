#' @title Calculate the 2D cross-correlation of two matrices using R-FFT.
#'
#' @description  This function calculates the 2D cross-correlation of two matrices
#'  `a` and `b` using R-FFT.
#'
#' @param a A matrix (2D array) of values.
#' @param b A matrix (2D array) of values.
#' @return A matrix representing the 2D cross-correlation of the input matrices.
#' @export
#' @examples
#' a <- matrix(c(1, 2, 3, 4), ncol = 2)
#' b <- matrix(c(5, 6, 7, 8), ncol = 2)
#' cc <- Xcorr2d_FFT_R(a, b)
#' image(cc)
#' @author Ahmed Homoudi
#' @seealso \link{PIV_obtain_grid}
#' @useDynLib idps
#' @importFrom stats fft
#' @export
Xcorr2d_FFT_R <- function(a, b) {
  # a<-a-mean(a); b<-b-mean(b)
  # the full CC matrix
  cc_row <- nrow(a) + nrow(b) - 1
  cc_col <- ncol(a) + ncol(b) - 1

  # a
  padded_a <- matrix(0, nrow = cc_row, ncol = cc_col)
  padded_a[1:nrow(a), 1:ncol(a)] <- a

  # b
  padded_b <- matrix(0, nrow = cc_row, ncol = cc_col)
  # padded_b[1:nrow(b), 1:ncol(b)]<-b#[nrow(b):1, ncol(b):1]
  padded_b[nrow(b):cc_row, ncol(b):cc_col] <- b[nrow(b):1, ncol(b):1]

  # fft
  ffta <- fft(padded_a)
  fftb <- fft(padded_b)

  # cc
  cc <- Re(fft(Conj(ffta) * fftb, inverse = TRUE)) / length(padded_a)
  # Re(fft(ffta * Conj(fftb), inverse = TRUE))

  return(cc)
}

# print(c(irow,icol))
# s<-(min_row_shift:max_row_shift)[irow]
# t<-(min_col_shift:max_col_shift)[icol]
# cc_indices[icc]<-icc
