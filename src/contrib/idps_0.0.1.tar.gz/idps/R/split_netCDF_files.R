#' @title Split Monthly files to system files.
#' @description A function to split the monthly netCDF files to precipitation
#' systems files, the splitting will search for time steps with precipitation less
#' than the provided threshold. Afterwards, this time step will be remove and
#' data after and before will be split to tmp netCDF files. The function can crop the data to
#' a spatial extent provided by shapefile or gpkg
#'
#' @param netCDF.file A character pointing to the netCDF file.
#' @param threshold A numeric value representing the minimum precipitation rate
#' that will be considered to delineate the precipitation objects, e.g. 5 mm/hr
#' @param sub_region A character pointing to a shapefile or gpkg to crop netCDF file.
#' @param output.path A character indicating where to place output files.
#'
#' @return netCDF file
#' @author Ahmed Homoudi
#' @export

split_netCDF_files <- function(netCDF.file,
                               threshold = NA,
                               sub_region = NA,
                               output.path = "~") {
  # stop if not a list
  stopifnot(!is.na(netCDF.file))

  r.rast <- terra::rast(netCDF.file)

  r.time <- terra::time(r.rast)
  # crop data to subregion
  if (!is.na(sub_region)) {
    sub_region <- terra::vect(sub_region)
    sub_region <- terra::project(sub_region, terra::crs(r.rast))
    r.rast <- terra::crop(r.rast, sub_region, mask = TRUE)
  }

  # remove pixels with rain rate less than threshold
  if (!is.na(threshold)) {
    r.rast[r.rast < threshold] <- 0
  }

  # find timesteps that don't have rain
  indices <- unlist(lapply(X = 1:terra::nlyr(r.rast), FUN = function(x) {
    if (all(r.rast[, , x] == 0)) {
      return("EMPTY")
    } else {
      return("NOTEMPTY")
    }
  }))

  # spilt into groups
  grb <- with(rle(indices), rep(seq_along(values), lengths))
  Groups <- split(indices, grb)

  # create meta data
  indices_df <- data.frame(
    r.steps = r.time,
    timeID = 1:length(r.time),
    indices = indices
  )

  indices_df <- cbind(
    indices_df,
    purrr::map_df(Groups, ~ tibble::tibble(x = .x), .id = "id")
  )

  unique_groups <- unique(indices_df$id)

  # split and write to disk
  lapply(1:length(unique_groups), function(x) {
    sub_df <- indices_df[indices_df$id == unique_groups[x], ]

    if (all(sub_df$x != "EMPTY")) {
      ncfname <- paste0(
        output.path,
        "3B-HHR.MS.MRG.3IMERG._",
        format(sub_df$r.steps[1], "%Y%m%d-%H%M%S"),
        "_",
        format(sub_df$r.steps[nrow(sub_df)], "%Y%m%d-%H%M%S"),
        "_precipitationCal_.nc"
      )

      terra::writeCDF(
        x = r.rast[[sub_df$timeID]],
        filename = ncfname,
        zname = "time",
        varname = "precipitation",
        compression = 9,
        missval = 1e32,
        overwrite = TRUE
      )
    }
  })
  message("Finishsed producing tmp/system files;-)")
}
