#' @title Particle Imaging Velocity (PIV)
#' @description A function estimate displacement vectors (PIV)
#'
#' @param binary_array A binary 3D array with a dimensions of (L, M, N). Where N is
#' greater or equal two.
#' @param  xcrds Coordinates along the x-axis.
#' @param  ycrds Coordinates along the y-axis.
#' @param  zaxis Coordinates along the z-axis, usually, time axis.
#' @param window_size The size of the sub window or interrogation window size. See also \link{PIV_obtain_grid}.
#' @param Dis.type In which form the displacement should be obtained. "st" as grid shifts, or "vu" as speed in m/sec.
#' Haversine formula will be used to convert degrees to meters.
#' @param write_netCDF A logical variable indicating if to save the results as netCDF file or not.
#' @param netCDF_name A character specifying the name of the netCDF file. it can include the full path.
#'
#' @return A list with two arrays (u & v) or a netCDF file
#' @author Ahmed Homoudi
#' @seealso \link{PIV_obtain_grid}
#' @importFrom stats na.omit
#' @export

PIV_Calculator <- function(
    binary_array,
    xcrds,
    ycrds,
    zaxis,
    window_size = 32,
    Dis.type = "st",
    write_netCDF = FALSE,
    netCDF_name) {
  # inform about the displacement indices
  message(
    "Since the sub window size is: ", window_size,
    ". The cross correlation matrix indices will vary from ", 1 - window_size,
    " to ", window_size - 1
  )

  # get velocity grid
  velocity_grid <- PIV_obtain_grid(
    xcrds,
    ycrds,
    window_size
  )

  # output dimensions
  DIM_binary <- dim(binary_array)

  DIM_PIV <- as.integer(c(
    length(unique(velocity_grid$y.ID)),
    length(unique(velocity_grid$x.ID)),
    DIM_binary[3] - 1
  ))

  # data resolution
  y.res <- mean(abs(diff(ycrds)), na.rm = TRUE)
  x.res <- mean(abs(diff(xcrds)), na.rm = TRUE)
  spat_res <- c(y.res, x.res)
  timestep <- as.numeric(mean(abs(diff(zaxis)))) # in mins
  # plot(grid_mat[,1], grid_mat[,2])

  if (Dis.type == "st") {
    # prepare grid indices
    grid_mat <- array(c(unlist(velocity_grid[, 2:1])),
      dim = c(nrow(velocity_grid), 2)
    )
    class(grid_mat) <- "array"

    result <- .Call(
      "c_PIV_st_f",
      DIM_ARRAY = as.integer(DIM_binary),
      grid_mat = as.double(grid_mat),
      DIM_PIV = as.integer(DIM_PIV),
      barray = as.double(binary_array)
    )
  } else if (Dis.type == "vu") {
    grid_mat <- array(c(unlist(velocity_grid[, c(2, 1, 8, 7)])),
      dim = c(nrow(velocity_grid), 4)
    )
    class(grid_mat) <- "array"

    result <- .Call(
      "c_PIV_uv_f",
      DIM_ARRAY = as.integer(DIM_binary),
      grid_mat = as.double(grid_mat),
      DIM_PIV = as.integer(DIM_PIV),
      barray = as.double(binary_array),
      timestep = as.double(timestep),
      spat_res = as.double(spat_res)
    )
  } else {
    stop("Please provide which PIV output should be calcuated. Shifts (st) or speed (vu)")
  }

  # write netcdf file
  if (write_netCDF & Dis.type == "st") {
    writeNetCDF(
      arrays = result,
      vars = "st",
      xcrds = unique(velocity_grid$x.centre),
      ycrds = unique(velocity_grid$y.centre),
      zcrds = zaxis[1:c(length(zaxis) - 1)],
      fcompression = 9,
      missval = NA,
      overwrite = TRUE,
      netCDF_name
    )
  } else if (write_netCDF & Dis.type == "vu") {
    writeNetCDF(
      arrays = result,
      vars = "vu",
      xcrds = unique(velocity_grid$x.centre),
      ycrds = unique(velocity_grid$y.centre),
      zcrds = zaxis[1:c(length(zaxis) - 1)],
      fcompression = 9,
      overwrite = TRUE,
      missval = NA,
      netCDF_name
    )
  }

  if (!write_netCDF) {
    return(result)
  }
}
