#' @title Particle Imaging Velocity (PIV)
#' @description A function estimate displacement vectors (PIV)
#'
#' @param binary_array A binary 3D array with a dimensions of (L, M, N). Where N is
#' greater or equal two.
#' @param  xcrds Coordinates along the x-axis.
#' @param  ycrds Coordinates along the y-axis.
#' @param  zaxis Coordinates along the z-axis, usually, time axis.
#' @param window_size The size of the sub window or interrogation window size. See also \link{PIV_obtain_grid}.
#' @param Dis.type In which form the displacement should be obtained. "st" as grid shifts, or "uv" as speed in m/sec.
#' Haversine formula will be used to convert degrees to meters.
#' @param write_netCDF A logical variable indicating if to save the results as netCDF file or not.
#' @param netCDF_name A character specifying the name of the netCDF file. it can include the full path.
#'
#' @return A list with two arrays (u & v) or a netCDF file
#' @author Ahmed Homoudi
#' @seealso \link{PIV_obtain_grid}
#' @importFrom stats na.omit
#' @export

PIV_Calculator <- function(
    binary_array,
    xcrds,
    ycrds,
    zaxis,
    window_size = 32,
    Dis.type = "st",
    write_netCDF = FALSE,
    netCDF_name) {
  message(
    "Since the sub window size is: ", window_size,
    ". The cross correlation matrix indices will vary from ", 1 - window_size,
    " to ", window_size - 1
  )


  velocity_grid <- PIV_obtain_grid(
    xcrds,
    ycrds,
    window_size
  )


  DIM_binary <- dim(binary_array)

  DIM_PIV <- as.integer(c(
    length(unique(velocity_grid$y.ID)),
    length(unique(velocity_grid$x.ID)),
    DIM_binary[3] - 1
  ))

  grid_mat <- array(c(unlist(velocity_grid[, 2:1])), dim = c(nrow(velocity_grid), 2))

  class(grid_mat) <- "array"
  # plot(grid_mat[,1], grid_mat[,2])

  if (Dis.type == "st") {
    result <- .Call(
      "c_PIV_st_f",
      DIM_ARRAY = as.integer(DIM_binary),
      grid_mat = as.double(grid_mat),
      DIM_PIV = as.integer(DIM_PIV),
      barray = as.double(binary_array)
    )
  } else if (Dis.type == "uv") {

  } else {
    stop("Please provide which PIV output should be calcuated. Shifts (st) or speed (uv)")
  }

  # write netcdf file
  if (write_netCDF) {
    r.s <- terra::rast(result[[1]])
    terra::ext(r.s) <- c(
      min(velocity_grid$x.centre),
      max(velocity_grid$x.centre),
      min(velocity_grid$y.centre),
      max(velocity_grid$y.centre)
    )
    terra::time(r.s) <- zaxis[1:c(length(zaxis) - 1)]
    terra::crs(r.s) <- "EPSG:4326"
    terra::varnames(r.s) <- "s"

    r.t <- terra::rast(result[[2]])
    terra::ext(r.t) <- c(
      min(velocity_grid$x.centre),
      max(velocity_grid$x.centre),
      min(velocity_grid$y.centre),
      max(velocity_grid$y.centre)
    )
    terra::time(r.t) <- zaxis[1:c(length(zaxis) - 1)]
    terra::crs(r.t) <- "EPSG:4326"
    terra::varnames(r.t) <- "t"



    terra::writeCDF(
      x = terra::sds(r.s, r.t),
      filename = netCDF_name,
      zname = "time",
      compression = 9,
      missval = 1e32,
      overwrite = TRUE
    )
  } else {
    return(result)
  }
}
