#' Convert Precipitation Cells or Systems to Well-Known Text
#'
#' @param x The input data. It can be as single object as XYM data frame, where M is
#' precipitation value. It can be a list of data frame (i.e. track) and each data
#' frame contains XYM information. Finally, it can be list of tracks (i.e. list of
#' list of data frames)
#' @details Please Provide the object or precipitation cell information as data frame with
#' colnames c("X", "Y", "PR").
#'
#' @export
Storm2WKT <- function(x) {
  # one object or precipitation cell
  if (is.data.frame(x)) {
    # check order of columns
    # x.names <- names(x)
    #
    # if (!identical(x.names, c("X", "Y", "PR"))) {
    #   message("Please revise the names and the order of the data frame columns")
    # }

    x.result <- df2WKT(x)

    x.result <- data.frame(
      timesep = NA,
      PC = x.result
    )

    return(x.result)
  } else {
    # multiple precipitation cells
    if (is.data.frame(x[[1]])) {
      x.names <- names(x)

      # convert each object to WKT
      x.result <- lapply(1:length(x), FUN = function(z) {
        subx <- x[[z]]

        return(df2WKT(subx))
      })

      x.result <- data.frame(
        timesep = x.names,
        PC = unlist(x.result)
      )

      return(x.result)

      # multiple precipitation systems
    } else if (is.data.frame(x[[1]][[1]])) {
      # top level names
      x.names <- names(x)

      x.result <- list()

      for (istorm in 1:length(x)) {
        subx <- x[[istorm]]

        x.tmp <- lapply(1:length(subx), FUN = function(z) {
          subx2 <- subx[[z]]

          return(df2WKT(subx2))
        })

        sub.names <- names(subx)

        x.result[[istorm]] <- data.frame(
          timesep = sub.names,
          PC = unlist(x.tmp)
        )
      }

      names(x.result) <- x.names

      return(x.result)
    } else {
      message("This neither a preciption cell, precipition system, nor a list of precipition systems")
    }
  }
}
