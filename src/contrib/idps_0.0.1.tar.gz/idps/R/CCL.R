#' @title Connected-component labeling (CCL)
#' @description A function that receives a binary 3D array and connect grids with
#' common labels. It uses 4 points connectivity. It connected object on each layer
#' and doesn't connect pixels in the third dimensions (i.e. n).
#' @param a input binary array. It be should an integer array.
#' @return  the output array containing the labels
#'
#' @export
CCL <- function(a) {
  stopifnot(is.integer(a))
  stopifnot(length(dim(a)) == 3)
  DIM <- dim(a)

  # l,m,n are the input array dimensions (row, columns, layers)
  l <- DIM[1]
  m <- DIM[2]
  n <- DIM[3]

  avec <- as.vector(unlist(matrix(a, ncol = 1)))
  result <- .Call(c_CCL_f, as.integer(DIM), as.double(avec))

  result <- array(result, dim = DIM)
  return(result)
}

# test
# a <- array(sample(0:1, 72, replace = T), dim = c(6, 6, 2))
# c <- a
# DIM <- dim(a)
# result <- array(.Fortran(i4block_components,
#   l = as.integer(DIM[1]),
#   m = as.integer(DIM[2]),
#   n = as.integer(DIM[3]),
#   a = as.integer(a),
#   c = as.integer(c)
# )$c, dim = DIM)
#
# result_dotCall64 <- array(dotCall64::.C64(
#   .NAME = "i4block_components",
#   SIGNATURE = c(
#     "integer",
#     "integer",
#     "integer",
#     "integer",
#     "integer"
#   ),
#   l = as.integer(DIM[1]),
#   m = as.integer(DIM[2]),
#   n = as.integer(DIM[3]),
#   a = as.integer(a),
#   c = as.integer(c)
# )$c, dim = DIM)
