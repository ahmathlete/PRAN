#' idps: A package for Identification and Description of Precipitation Systems.
#'
#' The idps package provides three categories of important functions:
#' foo, bar and baz.
#'
#' @section idps functions:
#' The idps functions ...
#'
#' @docType package
#' @name idps
#' @useDynLib idps, .registration=TRUE
NULL
#> NULL
