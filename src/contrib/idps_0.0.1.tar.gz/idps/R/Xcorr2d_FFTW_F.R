#' @title Calculate the 2D cross-correlation of two matrices using FFTW (C) library in Fortran.
#'
#' @description  This function calculates the 2D cross-correlation of two matrices
#'  `a` and `b` using FFTW (C) library in Fortran.
#'
#' @param a A matrix (2D array) of values.
#' @param b A matrix (2D array) of values.
#' @return A matrix representing the 2D cross-correlation of the input matrices.
#' @export
#' @examples
#' a <- matrix(c(1, 2, 3, 4), ncol = 2)
#' b <- matrix(c(5, 6, 7, 8), ncol = 2)
#' cc <- Xcorr2d_FFTW_F(a, b)
#' image(cc)
#' @author Ahmed Homoudi
#' @seealso \link{PIV_obtain_grid}
#' @useDynLib idps
#' @export
Xcorr2d_FFTW_F <- function(a, b) {
  DIMx <- dim(a)
  DIMy <- dim(a)
  avec <- as.vector(unlist(matrix(a, ncol = 1)))
  bvec <- as.vector(unlist(matrix(b, ncol = 1)))
  result <- .Call(
    "c_xcorr2d_FFTW_f",
    as.integer(DIMx),
    as.double(avec),
    as.integer(DIMy),
    as.double(b)
  )

  DIMz <- c(DIMx[1] + DIMy[1] - 1, DIMx[2] + DIMy[2] - 1)
  result <- array(result, dim = DIMz)
  return(result)
}
