#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <Rmath.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Arith.h>

void F77_NAME(add_f)(double *x, double *y, double *ret);
void F77_NAME(mul_f)(double *x, double *y, double *ret);
void F77_NAME(CCL_f)(int l, int m, int n, double *b1Darray, double *ccl1Darray);
void F77_NAME(xcorr2d_f)(int m, int n, int p, int q, int k, int l, double *a1Darray, double *b1Darray, double *cc1Darray);
void F77_NAME(xcorr2d_FFTW_f)(int m, int n, int p, int q, int k, int l, double *a1Darray, double *b1Darray, double *cc1Darray);
void F77_NAME(PIV_st_f)(int nrow1, int ncol1, int ntime1, double *barray,  \
              int nrow2, int ncol2, int ntime2, double *grid_mat, double *Sarray, double *Tarray);

extern SEXP c_add_f(SEXP x, SEXP y){
  SEXP ret;
  PROTECT(ret = allocVector(REALSXP, 1));
  F77_CALL(add_f)(REAL(x), REAL(y), REAL(ret));
  UNPROTECT(1);
  return(ret);

}
extern SEXP c_mul_f(SEXP x, SEXP y){
  SEXP ret;
  PROTECT(ret = allocVector(REALSXP, 1));
  F77_CALL(mul_f)(REAL(x), REAL(y), REAL(ret));
  UNPROTECT(1);
  return(ret);

}
extern SEXP c_CCL_f(SEXP dim, SEXP x){
  int l = INTEGER(dim)[0];
  int m = INTEGER(dim)[1];
  int n = INTEGER(dim)[2];
  SEXP ret = PROTECT(allocVector(REALSXP, l*m*n));
  F77_CALL(CCL_f)(l, m, n, REAL(x), REAL(ret));
  UNPROTECT(1);
  return(ret);

}
extern SEXP c_xcorr2d_f(SEXP dimx, SEXP x, SEXP dimy, SEXP y){
  int m = INTEGER(dimx)[0];
  int n = INTEGER(dimx)[1];
  //
  int p = INTEGER(dimy)[0];
  int q = INTEGER(dimy)[1];
  //
  int k = m + p - 1;
  int l = n + q - 1;

  SEXP ret = PROTECT(allocVector(REALSXP, k*l));
  F77_CALL(xcorr2d_f)(m, n, p, q, k, l, REAL(x), REAL(y), REAL(ret));
  UNPROTECT(1);
  return(ret);

}
extern SEXP c_xcorr2d_FFTW_f(SEXP dimx, SEXP x, SEXP dimy, SEXP y){
  int m = INTEGER(dimx)[0];
  int n = INTEGER(dimx)[1];
  //
  int p = INTEGER(dimy)[0];
  int q = INTEGER(dimy)[1];
  //
  int k = m + p - 1;
  int l = n + q - 1;

  SEXP ret = PROTECT(allocVector(REALSXP, k*l));
  F77_CALL(xcorr2d_FFTW_f)(m, n, p, q, k, l, REAL(x), REAL(y), REAL(ret));
  UNPROTECT(1);
  return(ret);

}
extern SEXP c_PIV_st_f(SEXP DIM_ARRAY, SEXP grid_mat, SEXP DIM_PIV, SEXP barray){
  int l1 = INTEGER(DIM_ARRAY)[0];
  int m1 = INTEGER(DIM_ARRAY)[1];
  int n1 = INTEGER(DIM_ARRAY)[2];
  //
  int l2 = INTEGER(DIM_PIV)[0];
  int m2 = INTEGER(DIM_PIV)[1];
  int n2 = INTEGER(DIM_PIV)[2];

  SEXP Sarray;
  SEXP Tarray;
  PROTECT(Sarray = alloc3DArray(REALSXP, l2, m2, n2));
  PROTECT(Tarray = alloc3DArray(REALSXP, l2, m2, n2));
  F77_CALL(PIV_st_f)(l1, m1, n1, REAL(barray),  \
           l2, m2, n2, REAL(grid_mat), REAL(Sarray), REAL(Tarray));
  SEXP list;

  /* Allocate the list object */
  PROTECT(list = Rf_allocVector(VECSXP, 2));

  /* Set the first element of the list to x */
  SET_VECTOR_ELT(list, 0, Sarray);

  /* Set the second element of the list to y */
  SET_VECTOR_ELT(list, 1, Tarray);

  UNPROTECT(3);
  return list;

}

SEXP c_ret_list(SEXP x, SEXP y) {
  SEXP list;

  /* Allocate the list object */
  PROTECT(list = Rf_allocVector(VECSXP, 2));

  /* Set the first element of the list to x */
  SET_VECTOR_ELT(list, 0, x);

  /* Set the second element of the list to y */
  SET_VECTOR_ELT(list, 1, y);

  /* Allocate and set the third element of the list to the type of x */
  // PROTECT(xtype = Rf_allocVector(STRSXP, 1));
  // SET_STRING_ELT(xtype, 0, Rf_mkChar(type2char(TYPEOF(x))));
  // SET_VECTOR_ELT(list, 2, xtype);

  /* Allocate and set the fourth element of the list to the type of y */
  //PROTECT(ytype = Rf_allocVector(STRSXP, 1));
  //SET_STRING_ELT(ytype, 0, Rf_mkChar(type2char(TYPEOF(y))));
  //SET_VECTOR_ELT(list, 3, ytype);

  /* Unprotect the objects and return the list */
  UNPROTECT(1);
  return list;
}

static const R_CallMethodDef CallEntries[] = {
  {"c_add_f",           (DL_FUNC) &c_add_f,             2},
  {"c_mul_f",           (DL_FUNC) &c_mul_f,             2},
  {"c_CCL_f",           (DL_FUNC) &c_CCL_f,             2},
  {"c_xcorr2d_f",       (DL_FUNC) &c_xcorr2d_f,         4},
  {"c_xcorr2d_FFTW_f",  (DL_FUNC) &c_xcorr2d_FFTW_f,    4},
  {"c_PIV_st_f",        (DL_FUNC) &c_PIV_st_f,          4},
  {"c_ret_list",        (DL_FUNC) &c_ret_list,          2},
  {NULL,         NULL,               0}
};

static const R_FortranMethodDef FEntries[] = {
  {NULL,         NULL,               0}
};

void R_init_idps(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, FEntries, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
